# Scientific Calculator
- ### Mini - Project for Computer Graphics - 3rd Semester
## Team :
- [__Pranav Yadav__](https://github.com/Pranav-yadav)
- __Harshit Shetty__
- __Rohit Rahatal__
